import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, FormArray } from '@angular/forms';
import { ViewChild, ElementRef } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import * as _ from 'underscore';
import { PagerService } from '../service/pager.service';
import { ExcelServiceService } from '../excel-service.service';
import { RouterModule, Routes, Router } from '@angular/router';
import { NumberValidatorsService } from "../number-validators.service";

@Component({
  selector: 'app-addnewinvoice',
  templateUrl: './addnewinvoice.component.html',
  styleUrls: ['./addnewinvoice.component.css']
})
export class AddnewinvoiceComponent implements OnInit {
  reimburshForm: FormGroup;
  salesListArray: FormArray;
  public addTableForm: FormGroup;
  public addInvoiceForm: FormGroup;
  public selectedAll: boolean;

  constructor(private formBuilder: FormBuilder) {

  }

  ngOnInit() {
    this.buildForm();

  }
  // buildForm() {
  //   this.reimburshForm = this.formBuilder.group({
  //     customerName: this.formBuilder.control(null),
  //     invoiceNumber: this.formBuilder.control({ value: null, disabled: true }),
  //     orderNumber: this.formBuilder.control(null),
  //     invoiceDate: this.formBuilder.control(null),
  //     terms: this.formBuilder.control(null),
  //     dueDate: this.formBuilder.control(null),
  //     salesPerson: this.formBuilder.control(null),
  //     salesList: this.formBuilder.array([
  //       this.formBuilder.group({
  //         itemDetail: this.formBuilder.control(null),
  //         quantity: this.formBuilder.control(null),
  //         rate: this.formBuilder.control(null),
  //         tax: this.formBuilder.control(null),
  //         amount: this.formBuilder.control("$0.00"),
  //       }),
  //     ]),

  //   });

  //   this.salesListArray = this.reimburshForm.get('salesList') as FormArray;
  //   console.log("submit  val", this.salesListArray);
  // }
  buildForm() {
    this.reimburshForm = this.formBuilder.group({
      customerName: this.formBuilder.control(null),
      invoiceNumber: this.formBuilder.control({ value: null, disabled: true }),
      orderNumber: this.formBuilder.control(null),
      invoiceDate: this.formBuilder.control(null),
      terms: this.formBuilder.control(null),
      dueDate: this.formBuilder.control(null),
      salesPerson: this.formBuilder.control(null),
      salesList: this.formBuilder.array([
        this.formBuilder.group({
          itemDetail: this.formBuilder.control(null),
          quantity: this.formBuilder.control(null),
          rate: this.formBuilder.control(null),
          tax: this.formBuilder.control(null),
          amount: this.formBuilder.control("$0.00"),
        }),
      ]),

    });

    this.salesListArray = this.reimburshForm.get('salesList') as FormArray;
    console.log("submit  val", this.salesListArray);
  }

  submitForm(value) {
    console.log(value);
  }

  addSalesListItem() {
    let formGroup: FormGroup = this.formBuilder.group({
      itemDetail: this.formBuilder.control(null),
      quantity: this.formBuilder.control(null),
      rate: this.formBuilder.control(null),
      tax: this.formBuilder.control(null),
      amount: this.formBuilder.control(null),
    });

    this.salesListArray.push(formGroup);
    console.log("added val", this.salesListArray);
  }

  deleteRow(index: number) {
    const control = <FormArray>this.reimburshForm.controls['salesList'];
    // remove the chosen row
    control.removeAt(index);

  }
}
